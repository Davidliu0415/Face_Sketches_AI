from __future__ import annotations

import argparse
import csv
import sys
import time
from datetime import datetime
from pathlib import Path

import torch
from torch.utils.data import DataLoader, Subset

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from configs import datasets_config as data_config
from configs import params
from data.dataset import FaceSketchPairDataset, FaceSketchTripletDataset
from eval.metrics import cosine_scores
from network import TripletLoss
from training.main import build_model, set_seed
from training.train import autocast_context, evaluate_triplet_epoch, train_one_epoch

BASELINE_TRIPLET_WEIGHT = 1.0
BASELINE_FACE_CE_WEIGHT = 0.0
BASELINE_SKETCH_CE_WEIGHT = 0.0


def parse_args():
    parser = argparse.ArgumentParser(description="Run stage-1 Face-Sketch embedding baseline.")
    parser.add_argument("--run-id", default="baseline_001")
    parser.add_argument("--train-manifest", default=str(data_config.train_manifest))
    parser.add_argument("--val-manifest", default=str(data_config.val_manifest))
    parser.add_argument("--image-root", default=str(data_config.image_root))
    parser.add_argument("--epochs", type=int, default=params.epochs)
    parser.add_argument("--batch-size", type=int, default=params.batch_size)
    parser.add_argument("--eval-batch-size", type=int, default=params.eval_batch_size)
    parser.add_argument("--accumulation-steps", type=int, default=params.accumulation_steps)
    parser.add_argument("--lr", type=float, default=params.lr)
    parser.add_argument("--num-workers", type=int, default=params.num_workers)
    parser.add_argument("--log-interval", type=int, default=100)
    parser.add_argument("--checkpoint", default="")
    parser.add_argument("--output-dir", default=str(PROJECT_ROOT / "checkpoints" / "research_1"))
    parser.add_argument("--skip-train", action="store_true")
    parser.add_argument("--skip-val", action="store_true")
    parser.add_argument("--skip-test", action="store_true")
    parser.add_argument("--limit-train", type=int, default=0)
    parser.add_argument("--limit-val", type=int, default=0)
    parser.add_argument("--limit-test", type=int, default=0)
    parser.add_argument("--seed", type=int, default=params.seed)

    amp_group = parser.add_mutually_exclusive_group()
    amp_group.add_argument("--amp", dest="amp", action="store_true", default=params.use_amp)
    amp_group.add_argument("--no-amp", dest="amp", action="store_false")
    return parser.parse_args()


def build_grad_scaler(device, enabled):
    if not enabled or device.type != "cuda":
        return None
    try:
        return torch.amp.GradScaler("cuda", enabled=True)
    except (AttributeError, TypeError):
        return torch.cuda.amp.GradScaler(enabled=True)


def maybe_limit(dataset, limit: int):
    if limit and limit > 0:
        return Subset(dataset, range(min(limit, len(dataset))))
    return dataset


def make_loader(dataset, batch_size, shuffle, num_workers, drop_last=False):
    return DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=torch.cuda.is_available(),
        persistent_workers=num_workers > 0,
        drop_last=drop_last,
    )


def save_checkpoint(path: Path, model, epoch: int, val_loss: float | None, args) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(
        {
            "model": model.state_dict(),
            "epoch": epoch,
            "val_loss": val_loss,
            "baseline_weights": {
                "triplet_weight": BASELINE_TRIPLET_WEIGHT,
                "face_ce_weight": BASELINE_FACE_CE_WEIGHT,
                "sketch_ce_weight": BASELINE_SKETCH_CE_WEIGHT,
            },
            "config": {
                "embedding_size": params.embedding_size,
                "dropout": params.dropout,
                "face_num_classes": params.face_num_classes,
                "sketch_num_classes": params.sketch_num_classes,
                "arcface_scale": params.arcface_scale,
                "arcface_margin": params.arcface_margin,
                "triplet_margin": params.triplet_margin,
                "image_size": params.image_size,
            },
            "args": vars(args),
        },
        path,
    )


def load_checkpoint(path: str | Path, model, device) -> None:
    checkpoint = torch.load(path, map_location=device)
    state_dict = checkpoint["model"] if isinstance(checkpoint, dict) and "model" in checkpoint else checkpoint
    model.load_state_dict(state_dict)


@torch.no_grad()
def embed_pair_dataset(model, data_loader, device, use_amp=False):
    model.eval()
    face_embeddings = []
    sketch_embeddings = []
    face_paths = []
    sketch_paths = []
    identities = []

    for batch in data_loader:
        face = batch["face"].to(device, non_blocking=True)
        sketch = batch["sketch"].to(device, non_blocking=True)
        with autocast_context(device, use_amp):
            face_embeddings.append(model.embed(face).float().cpu())
            sketch_embeddings.append(model.embed(sketch).float().cpu())
        face_paths.extend(list(batch["face_path"]))
        sketch_paths.extend(list(batch["sketch_path"]))
        identities.extend(list(batch["identity"]))

    return (
        torch.cat(face_embeddings, dim=0),
        torch.cat(sketch_embeddings, dim=0),
        face_paths,
        sketch_paths,
        identities,
    )


def retrieval_report(face_embeddings, sketch_embeddings, face_paths, sketch_paths, identities, run_id, dataset_name):
    scores = cosine_scores(face_embeddings, sketch_embeddings)
    target = torch.arange(scores.size(0), device=scores.device)
    top5_k = min(5, scores.size(1))
    _, top5_predictions = scores.topk(top5_k, dim=1)
    top1_predictions = top5_predictions[:, 0]

    top1 = top1_predictions.eq(target).float().mean().item()
    top5 = top5_predictions.eq(target.view(-1, 1)).any(dim=1).float().mean().item()
    positive_scores = scores.diag()

    failures = []
    for index, predicted_index in enumerate(top1_predictions.tolist()):
        if predicted_index == index:
            continue

        correct_score = positive_scores[index].item()
        predicted_score = scores[index, predicted_index].item()
        correct_rank = int((scores[index] > positive_scores[index]).sum().item() + 1)
        failures.append(
            {
                "run_id": run_id,
                "dataset": dataset_name,
                "identity": identities[index],
                "face_image": face_paths[index],
                "predicted_sketch": sketch_paths[predicted_index],
                "correct_sketch": sketch_paths[index],
                "similarity": f"{predicted_score:.6f}",
                "correct_similarity": f"{correct_score:.6f}",
                "rank": correct_rank,
                "error_type": "",
                "notes": "",
            }
        )

    return {
        "top1": top1,
        "top5": top5,
        "mean_positive_cosine": positive_scores.mean().item(),
    }, failures


def run_test_set(model, name: str, face_dir: Path, sketch_dir: Path, args, device):
    started_at = time.perf_counter()
    dataset = FaceSketchPairDataset.from_directories(
        face_dir=face_dir,
        sketch_dir=sketch_dir,
        image_size=params.image_size,
    )
    dataset = maybe_limit(dataset, args.limit_test)
    loader = make_loader(dataset, args.eval_batch_size, shuffle=False, num_workers=args.num_workers)
    face_embeddings, sketch_embeddings, face_paths, sketch_paths, identities = embed_pair_dataset(
        model,
        loader,
        device,
        use_amp=args.amp,
    )
    metrics, failures = retrieval_report(
        face_embeddings=face_embeddings,
        sketch_embeddings=sketch_embeddings,
        face_paths=face_paths,
        sketch_paths=sketch_paths,
        identities=identities,
        run_id=args.run_id,
        dataset_name=name,
    )
    runtime_seconds = time.perf_counter() - started_at
    print(
        f"[Test:{name}] samples={len(dataset)} "
        f"top1={metrics['top1']:.4f} top5={metrics['top5']:.4f} "
        f"positive_cos={metrics['mean_positive_cosine']:.4f} "
        f"runtime={runtime_seconds:.2f}s",
        flush=True,
    )
    return {"name": name, "samples": len(dataset), "runtime_seconds": runtime_seconds, **metrics}, failures


def write_baseline_results(path: Path, rows: list[dict]) -> None:
    fieldnames = [
        "run_id",
        "dataset",
        "train_samples",
        "val_samples",
        "test_samples",
        "top1",
        "top5",
        "mean_positive_cosine",
        "runtime_seconds",
        "checkpoint",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def write_failed_matches(path: Path, rows: list[dict]) -> None:
    fieldnames = [
        "run_id",
        "dataset",
        "identity",
        "face_image",
        "predicted_sketch",
        "correct_sketch",
        "similarity",
        "correct_similarity",
        "rank",
        "error_type",
        "notes",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    args = parse_args()
    started_at = time.perf_counter()
    set_seed(args.seed)
    device = params.device

    if device.type == "cuda":
        torch.backends.cudnn.benchmark = True
        try:
            torch.set_float32_matmul_precision("high")
        except AttributeError:
            pass

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_dir = Path(args.output_dir) / f"{args.run_id}_{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)

    best_path = run_dir / "best.pth"
    last_path = run_dir / "last.pth"
    metrics_path = run_dir / "metrics.csv"
    results_path = run_dir / "baseline_results.csv"
    failures_path = run_dir / "failed_matches.csv"

    model = build_model(device)
    scaler = build_grad_scaler(device, args.amp)
    criterion = TripletLoss(margin=params.triplet_margin)

    print(f"Run ID: {args.run_id}", flush=True)
    print(f"Device: {device}", flush=True)
    print(f"Project root: {PROJECT_ROOT}", flush=True)
    print(f"Output dir: {run_dir}", flush=True)
    print(
        "Baseline weights: "
        f"triplet={BASELINE_TRIPLET_WEIGHT}, "
        f"face_ce={BASELINE_FACE_CE_WEIGHT}, "
        f"sketch_ce={BASELINE_SKETCH_CE_WEIGHT}",
        flush=True,
    )

    if args.checkpoint:
        load_checkpoint(args.checkpoint, model, device)
        print(f"Loaded checkpoint: {args.checkpoint}", flush=True)

    train_samples = ""
    val_samples = ""
    checkpoint_for_results = ""
    best_val_loss = float("inf")

    if not args.skip_train:
        train_dataset = FaceSketchTripletDataset(args.train_manifest, args.image_root, image_size=params.image_size)
        train_dataset = maybe_limit(train_dataset, args.limit_train)
        train_samples = len(train_dataset)
        train_loader = make_loader(
            train_dataset,
            args.batch_size,
            shuffle=True,
            num_workers=args.num_workers,
            drop_last=len(train_dataset) >= args.batch_size,
        )
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=params.weight_decay)

        val_loader = None
        if not args.skip_val:
            val_dataset = FaceSketchTripletDataset(args.val_manifest, args.image_root, image_size=params.image_size)
            val_dataset = maybe_limit(val_dataset, args.limit_val)
            val_samples = len(val_dataset)
            val_loader = make_loader(val_dataset, args.eval_batch_size, shuffle=False, num_workers=args.num_workers)

        with metrics_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(
                handle,
                fieldnames=[
                    "epoch",
                    "train_loss",
                    "train_triplet_loss",
                    "train_triplet_acc",
                    "val_loss",
                    "val_triplet_loss",
                    "val_triplet_acc",
                ],
            )
            writer.writeheader()

            for epoch in range(1, args.epochs + 1):
                train_stats = train_one_epoch(
                    model=model,
                    data_loader=train_loader,
                    optimizer=optimizer,
                    device=device,
                    triplet_loss=criterion,
                    triplet_weight=BASELINE_TRIPLET_WEIGHT,
                    face_ce_weight=BASELINE_FACE_CE_WEIGHT,
                    sketch_ce_weight=BASELINE_SKETCH_CE_WEIGHT,
                    log_interval=args.log_interval,
                    accumulation_steps=args.accumulation_steps,
                    use_amp=args.amp,
                    scaler=scaler,
                )

                val_stats = None
                if val_loader is not None:
                    val_stats = evaluate_triplet_epoch(
                        model=model,
                        data_loader=val_loader,
                        device=device,
                        triplet_loss=criterion,
                        triplet_weight=BASELINE_TRIPLET_WEIGHT,
                        face_ce_weight=BASELINE_FACE_CE_WEIGHT,
                        sketch_ce_weight=BASELINE_SKETCH_CE_WEIGHT,
                        log_interval=args.log_interval,
                        use_amp=args.amp,
                    )
                    if val_stats.loss < best_val_loss:
                        best_val_loss = val_stats.loss
                        save_checkpoint(best_path, model, epoch, best_val_loss, args)

                save_checkpoint(last_path, model, epoch, val_stats.loss if val_stats else None, args)
                if val_stats is None and not best_path.exists():
                    save_checkpoint(best_path, model, epoch, None, args)

                writer.writerow(
                    {
                        "epoch": epoch,
                        "train_loss": train_stats.loss,
                        "train_triplet_loss": train_stats.triplet_loss,
                        "train_triplet_acc": train_stats.triplet_acc,
                        "val_loss": val_stats.loss if val_stats else "",
                        "val_triplet_loss": val_stats.triplet_loss if val_stats else "",
                        "val_triplet_acc": val_stats.triplet_acc if val_stats else "",
                    }
                )
                handle.flush()

                if val_stats:
                    print(
                        f"[Epoch {epoch}/{args.epochs}] "
                        f"train_loss={train_stats.loss:.4f} "
                        f"train_triplet_acc={train_stats.triplet_acc:.4f} "
                        f"val_loss={val_stats.loss:.4f} "
                        f"val_triplet_acc={val_stats.triplet_acc:.4f}",
                        flush=True,
                    )
                else:
                    print(
                        f"[Epoch {epoch}/{args.epochs}] "
                        f"train_loss={train_stats.loss:.4f} "
                        f"train_triplet_acc={train_stats.triplet_acc:.4f}",
                        flush=True,
                    )

        if best_path.exists():
            load_checkpoint(best_path, model, device)
            checkpoint_for_results = str(best_path)
            print(f"Testing with best checkpoint: {best_path}", flush=True)
        elif last_path.exists():
            checkpoint_for_results = str(last_path)
            print(f"Testing with last checkpoint: {last_path}", flush=True)

    elif not args.skip_val:
        val_dataset = FaceSketchTripletDataset(args.val_manifest, args.image_root, image_size=params.image_size)
        val_dataset = maybe_limit(val_dataset, args.limit_val)
        val_samples = len(val_dataset)
        val_loader = make_loader(val_dataset, args.eval_batch_size, shuffle=False, num_workers=args.num_workers)
        val_stats = evaluate_triplet_epoch(
            model=model,
            data_loader=val_loader,
            device=device,
            triplet_loss=criterion,
            triplet_weight=BASELINE_TRIPLET_WEIGHT,
            face_ce_weight=BASELINE_FACE_CE_WEIGHT,
            sketch_ce_weight=BASELINE_SKETCH_CE_WEIGHT,
            log_interval=args.log_interval,
            use_amp=args.amp,
        )
        print(f"[Val] loss={val_stats.loss:.4f} triplet_acc={val_stats.triplet_acc:.4f}", flush=True)

    if args.checkpoint:
        checkpoint_for_results = args.checkpoint

    result_rows = []
    failed_match_rows = []
    if not args.skip_test:
        test_sets = [
            (
                "dataset01",
                Path(data_config.test_dataset01) / "archive" / "photos",
                Path(data_config.test_dataset01) / "archive" / "sketches",
            ),
            (
                "dataset02",
                Path(data_config.test_dataset02) / "archive" / "photos",
                Path(data_config.test_dataset02) / "archive" / "sketches",
            ),
        ]
        for name, face_dir, sketch_dir in test_sets:
            test_result, failures = run_test_set(model, name, face_dir, sketch_dir, args, device)
            result_rows.append(
                {
                    "run_id": args.run_id,
                    "dataset": name,
                    "train_samples": train_samples,
                    "val_samples": val_samples,
                    "test_samples": test_result["samples"],
                    "top1": f"{test_result['top1']:.6f}",
                    "top5": f"{test_result['top5']:.6f}",
                    "mean_positive_cosine": f"{test_result['mean_positive_cosine']:.6f}",
                    "runtime_seconds": f"{test_result['runtime_seconds']:.2f}",
                    "checkpoint": checkpoint_for_results,
                }
            )
            failed_match_rows.extend(failures)

    write_baseline_results(results_path, result_rows)
    write_failed_matches(failures_path, failed_match_rows)

    total_runtime = time.perf_counter() - started_at
    print(f"baseline_results.csv: {results_path}", flush=True)
    print(f"failed_matches.csv: {failures_path}", flush=True)
    print(f"Total runtime: {total_runtime:.2f}s", flush=True)


if __name__ == "__main__":
    main()
